import 'package:flutter/foundation.dart';
import '../models/habit.dart';
import '../repositories/interfaces/habit_repository.dart';

class HabitController extends ChangeNotifier {
  final HabitRepository _repo;

  HabitController(this._repo);

  String _userId = 'mock_user_123';
  List<Habit> _habits = [];
  List<HabitLog> _currentLogs = [];
  bool _isLoading = false;

  List<Habit> get habits => _habits;
  List<Habit> get positiveHabits => _habits.where((h) => h.type == HabitType.positive).toList();
  List<Habit> get negativeHabits => _habits.where((h) => h.type == HabitType.negative).toList();
  List<HabitLog> get currentLogs => _currentLogs;
  bool get isLoading => _isLoading;

  Future<void> loadHabits(String userId) async {
    _userId = userId;
    _isLoading = true;
    notifyListeners();

    try {
      _habits = await _repo.getActiveHabits(userId);
    } catch (e) {
      print('Erro ao carregar hábitos: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadHabitLogs(String habitId) async {
    final now = DateTime.now();
    final startOfMonth = DateTime(now.year, now.month, 1);
    _currentLogs = await _repo.getHabitLogsByDateRange(habitId, startOfMonth, now);
    notifyListeners();
  }

  Future<void> addHabit(Habit habit) async {
    await _repo.addHabit(habit);
    await loadHabits(_userId);
  }

  Future<void> updateHabit(Habit habit) async {
    await _repo.updateHabit(habit);
    await loadHabits(_userId);
  }

  Future<void> deleteHabit(String id) async {
    await _repo.deleteHabit(id);
    await loadHabits(_userId);
  }

  Future<void> addHabitLog(HabitLog log) async {
    await _repo.addHabitLog(log);
    await loadHabitLogs(log.habitId);
    notifyListeners();
  }

  Future<void> deleteHabitLog(String id) async {
    await _repo.deleteHabitLog(id);
    notifyListeners();
  }

  Future<int> getDaysWithoutOccurrence(String habitId) async {
    return await _repo.getDaysWithoutOccurrence(habitId);
  }
}
