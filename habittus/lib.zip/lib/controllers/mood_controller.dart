import 'package:flutter/foundation.dart';
import '../models/mood.dart';
import '../repositories/interfaces/mood_repository.dart';

class MoodController extends ChangeNotifier {
  final MoodRepository _repo;

  MoodController(this._repo);

  DateTime selectedDate = DateTime.now();
  MoodEntry? selected;
  List<MoodEntry> weekLogs = const [];

  Future<void> load(DateTime date) async {
    selectedDate = _dateOnly(date);
    selected = await _repo.getForDate(selectedDate);
    await _loadWeek();
    notifyListeners();
  }

  Future<void> _loadWeek() async {
    final end = selectedDate;
    final start = end.subtract(const Duration(days: 6));
    final List<MoodEntry> logs = [];
    for (int i = 0; i < 7; i++) {
      final day = _dateOnly(start.add(Duration(days: i)));
      final log = await _repo.getForDate(day);
      if (log != null) logs.add(log);
    }
    weekLogs = List.unmodifiable(logs);
  }

  void select(MoodEntry mood) {
    selected = mood;
    notifyListeners();
  }

  Future<void> save(MoodEntry mood) async {
    await _repo.save(mood.copyWith(date: selectedDate));
    selected = mood;
    await _loadWeek();
    notifyListeners();
  }

  DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);
}
