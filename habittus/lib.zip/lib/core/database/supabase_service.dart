import 'package:supabase_flutter/supabase_flutter.dart';

/// Design Pattern: SINGLETON
/// 
/// O SupabaseService implementa o padrão Singleton para garantir
/// que existe apenas uma instância do cliente Supabase em toda a aplicação.
/// 
/// Benefícios:
/// - Gestão centralizada da conexão à base de dados
/// - Reutilização eficiente de recursos
/// - Ponto único de configuração
/// 
class SupabaseService {
  // Instância única (Singleton)
  static SupabaseService? _instance;
  
  // Cliente Supabase
  late final SupabaseClient _client;
  
  // Construtor privado
  SupabaseService._();
  
  /// Obtém a instância única do SupabaseService
  static SupabaseService get instance {
    _instance ??= SupabaseService._();
    return _instance!;
  }
  
  /// Inicializa a conexão com Supabase
  /// Deve ser chamado uma vez no início da aplicação
  static Future<void> initialize({
    required String url,
    required String anonKey,
  }) async {
    await Supabase.initialize(
      url: url,
      anonKey: anonKey,
    );
    instance._client = Supabase.instance.client;
  }
  
  /// Obtém o cliente Supabase
  SupabaseClient get client => _client;
  
  /// Obtém o utilizador atual autenticado
  User? get currentUser => _client.auth.currentUser;
  
  /// Verifica se existe um utilizador autenticado
  bool get isAuthenticated => currentUser != null;
  
  /// Stream de mudanças de autenticação
  Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;
  
  // ==================== AUTH METHODS ====================
  
  /// Regista um novo utilizador
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    Map<String, dynamic>? data,
  }) async {
    return await _client.auth.signUp(
      email: email,
      password: password,
      data: data,
    );
  }
  
  /// Faz login com email e password
  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    return await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }
  
  /// Faz logout
  Future<void> signOut() async {
    await _client.auth.signOut();
  }
  
  /// Atualiza a password do utilizador
  Future<UserResponse> updatePassword(String newPassword) async {
    return await _client.auth.updateUser(
      UserAttributes(password: newPassword),
    );
  }
  
  /// Envia email de recuperação de password
  Future<void> resetPassword(String email) async {
    await _client.auth.resetPasswordForEmail(email);
  }
  
  // ==================== DATABASE HELPERS ====================
  
  /// Obtém referência a uma tabela
  SupabaseQueryBuilder from(String table) => _client.from(table);
  
  /// Executa uma função RPC
  Future<dynamic> rpc(String functionName, {Map<String, dynamic>? params}) async {
    return await _client.rpc(functionName, params: params);
  }
}
