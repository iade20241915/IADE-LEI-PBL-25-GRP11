import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/physical_activity.dart';
import '../interfaces/activity_repository.dart';

/// Implementação Supabase do repositório de atividades físicas
class SupabaseActivityRepository implements ActivityRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _table = SupabaseConfig.activityTable;
  static const String _trackPointsTable = SupabaseConfig.activityTrackPointsTable;

  @override
  Future<List<PhysicalActivity>> getByDateRange(
    DateTime startDate,
    DateTime endDate,
    String visitorId,
  ) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', int.parse(visitorId))
          .gte('activity_date', startDate.toIso8601String().split('T')[0])
          .lte('activity_date', endDate.toIso8601String().split('T')[0])
          .order('activity_date', ascending: true);

      final activities = <PhysicalActivity>[];
      for (final data in response as List) {
        final activity = _fromJson(data);
        // Carregar track points se existirem
        final trackPoints = await _getTrackPoints(data['activity_id'] as int);
        activities.add(activity.copyWith(
          startLocation: trackPoints.where((p) => p.sequence == 1).firstOrNull,
          endLocation: trackPoints.where((p) => p.sequence == 2).firstOrNull,
        ));
      }
      
      return activities;
    } catch (e) {
      print('Erro ao obter atividades: $e');
      return [];
    }
  }

  @override
  Future<PhysicalActivity?> add(PhysicalActivity activity) async {
    try {
      final data = _toJson(activity);
      final response = await _supabase
          .from(_table)
          .insert(data)
          .select()
          .single();

      final activityId = response['activity_id'] as int;
      
      // Guardar track points se existirem
      if (activity.startLocation != null) {
        await _saveTrackPoint(activityId, activity.startLocation!);
      }
      if (activity.endLocation != null) {
        await _saveTrackPoint(activityId, activity.endLocation!);
      }

      return _fromJson(response).copyWith(
        startLocation: activity.startLocation,
        endLocation: activity.endLocation,
      );
    } catch (e) {
      print('Erro ao adicionar atividade: $e');
      return null;
    }
  }

  @override
  Future<PhysicalActivity?> update(PhysicalActivity activity) async {
    try {
      final data = _toJson(activity);
      final activityId = int.parse(activity.id);
      
      final response = await _supabase
          .from(_table)
          .update(data)
          .eq('activity_id', activityId)
          .select()
          .single();

      // Atualizar track points
      await _supabase.from(_trackPointsTable).delete().eq('activity_id', activityId);
      
      if (activity.startLocation != null) {
        await _saveTrackPoint(activityId, activity.startLocation!);
      }
      if (activity.endLocation != null) {
        await _saveTrackPoint(activityId, activity.endLocation!);
      }

      return _fromJson(response).copyWith(
        startLocation: activity.startLocation,
        endLocation: activity.endLocation,
      );
    } catch (e) {
      print('Erro ao atualizar atividade: $e');
      return null;
    }
  }

  @override
  Future<bool> delete(String id) async {
    try {
      final activityId = int.parse(id);
      // Track points são removidos automaticamente por CASCADE
      await _supabase.from(_table).delete().eq('activity_id', activityId);
      return true;
    } catch (e) {
      print('Erro ao remover atividade: $e');
      return false;
    }
  }

  /// Obtém resumo semanal para gráfico
  Future<ActivityWeeklySummary> getWeeklySummary(
    DateTime startDate,
    String visitorId,
  ) async {
    final endDate = startDate.add(const Duration(days: 6));
    final activities = await getByDateRange(startDate, endDate, visitorId);
    
    final dailyMinutes = <DateTime, int>{};
    final dailyCalories = <DateTime, int>{};
    
    for (int i = 0; i < 7; i++) {
      final date = DateTime(startDate.year, startDate.month, startDate.day + i);
      dailyMinutes[date] = 0;
      dailyCalories[date] = 0;
    }
    
    for (final activity in activities) {
      final date = DateTime(
        activity.timestamp.year,
        activity.timestamp.month,
        activity.timestamp.day,
      );
      dailyMinutes[date] = (dailyMinutes[date] ?? 0) + activity.durationMinutes;
      dailyCalories[date] = (dailyCalories[date] ?? 0) + (activity.caloriesBurned ?? 0);
    }

    final totalMinutes = activities.fold<int>(0, (sum, a) => sum + a.durationMinutes);
    final totalCalories = activities.fold<int>(0, (sum, a) => sum + (a.caloriesBurned ?? 0));

    return ActivityWeeklySummary(
      startDate: startDate,
      activities: activities,
      dailyMinutes: dailyMinutes,
      dailyCalories: dailyCalories,
      totalMinutes: totalMinutes,
      totalCalories: totalCalories,
      totalActivities: activities.length,
    );
  }

  /// Calcula valores normalizados para gráfico (0.0 a 1.0, meta = 60min/dia)
  List<double> getWeeklyChartValues(ActivityWeeklySummary summary) {
    final values = <double>[];
    final sortedDates = summary.dailyMinutes.keys.toList()..sort();
    
    for (final date in sortedDates) {
      final minutes = summary.dailyMinutes[date] ?? 0;
      // Normalizar para 60 minutos
      values.add((minutes / 60).clamp(0.0, 1.5));
    }
    
    return values;
  }

  // ==================== HELPERS PRIVADOS ====================

  Future<List<GpsTrackPoint>> _getTrackPoints(int activityId) async {
    try {
      final response = await _supabase
          .from(_trackPointsTable)
          .select()
          .eq('activity_id', activityId)
          .order('seq', ascending: true);

      return (response as List)
          .map((e) => GpsTrackPoint.fromJson(e))
          .toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> _saveTrackPoint(int activityId, GpsTrackPoint point) async {
    await _supabase.from(_trackPointsTable).insert(point.toJson(activityId));
  }

  PhysicalActivity _fromJson(Map<String, dynamic> json) {
    return PhysicalActivity(
      id: json['activity_id'].toString(),
      userId: json['visitor_id'].toString(),
      timestamp: DateTime.parse(json['activity_date'] as String),
      activityType: _parseActivityType(json['activity_type_id']),
      durationMinutes: json['duration_min'] as int,
      intensity: _parseIntensity(json['intensity']),
      distanceKm: (json['distance_km'] as num?)?.toDouble(),
      caloriesBurned: json['calories_burned'] as int?,
      notes: json['notes'] as String?,
    );
  }

  Map<String, dynamic> _toJson(PhysicalActivity activity) {
    return {
      'visitor_id': int.parse(activity.userId),
      'activity_type_id': _activityTypeToId(activity.activityType),
      'activity_date': activity.timestamp.toIso8601String().split('T')[0],
      'duration_min': activity.durationMinutes,
      'intensity': activity.intensity.name,
      'distance_km': activity.distanceKm,
      'calories_burned': activity.caloriesBurned,
      'notes': activity.notes,
    };
  }

  ActivityType _parseActivityType(dynamic typeId) {
    // Mapear IDs da BD para enum
    const typeMap = {
      1: ActivityType.running,
      2: ActivityType.walking,
      3: ActivityType.cycling,
      4: ActivityType.swimming,
      5: ActivityType.gym,
      6: ActivityType.yoga,
      7: ActivityType.dance,
      8: ActivityType.soccer,
      9: ActivityType.basketball,
      10: ActivityType.tennis,
      11: ActivityType.hiking,
    };
    return typeMap[typeId] ?? ActivityType.other;
  }

  int _activityTypeToId(ActivityType type) {
    const typeMap = {
      ActivityType.running: 1,
      ActivityType.walking: 2,
      ActivityType.cycling: 3,
      ActivityType.swimming: 4,
      ActivityType.gym: 5,
      ActivityType.yoga: 6,
      ActivityType.dance: 7,
      ActivityType.soccer: 8,
      ActivityType.basketball: 9,
      ActivityType.tennis: 10,
      ActivityType.hiking: 11,
      ActivityType.other: 12,
    };
    return typeMap[type] ?? 12;
  }

  ActivityIntensity _parseIntensity(dynamic intensity) {
    if (intensity == null) return ActivityIntensity.moderate;
    switch (intensity.toString().toLowerCase()) {
      case 'low':
        return ActivityIntensity.low;
      case 'high':
        return ActivityIntensity.high;
      default:
        return ActivityIntensity.moderate;
    }
  }
}

/// Resumo semanal de atividades
class ActivityWeeklySummary {
  final DateTime startDate;
  final List<PhysicalActivity> activities;
  final Map<DateTime, int> dailyMinutes;
  final Map<DateTime, int> dailyCalories;
  final int totalMinutes;
  final int totalCalories;
  final int totalActivities;

  ActivityWeeklySummary({
    required this.startDate,
    required this.activities,
    required this.dailyMinutes,
    required this.dailyCalories,
    required this.totalMinutes,
    required this.totalCalories,
    required this.totalActivities,
  });

  String get totalTimeFormatted {
    final hours = totalMinutes ~/ 60;
    final minutes = totalMinutes % 60;
    return '${hours}h${minutes.toString().padLeft(2, '0')}';
  }
}
