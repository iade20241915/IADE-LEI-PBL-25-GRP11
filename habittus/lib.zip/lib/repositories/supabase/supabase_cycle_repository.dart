import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/cycle_entry_model.dart';

/// Implementação Supabase do repositório de ciclo menstrual
class SupabaseCycleRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _table = SupabaseConfig.cycleEntryTable;

  /// Obtém entrada de uma data específica
  Future<CycleEntryModel?> getByDate(DateTime date, int visitorId) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .eq('entry_date', date.toIso8601String().split('T')[0])
          .maybeSingle();

      if (response == null) return null;
      return CycleEntryModel.fromJson(response);
    } catch (e) {
      print('Erro ao obter entrada do ciclo: $e');
      return null;
    }
  }

  /// Obtém entradas de um período
  Future<List<CycleEntryModel>> getByDateRange(
    DateTime startDate,
    DateTime endDate,
    int visitorId,
  ) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .gte('entry_date', startDate.toIso8601String().split('T')[0])
          .lte('entry_date', endDate.toIso8601String().split('T')[0])
          .order('entry_date', ascending: true);

      return (response as List)
          .map((e) => CycleEntryModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao obter entradas do ciclo: $e');
      return [];
    }
  }

  /// Guarda ou atualiza entrada
  Future<CycleEntryModel?> save(CycleEntryModel entry) async {
    try {
      final existing = await getByDate(entry.entryDate, entry.visitorId);
      
      if (existing != null) {
        final response = await _supabase
            .from(_table)
            .update(entry.toJson())
            .eq('cycle_entry_id', existing.cycleEntryId)
            .select()
            .single();
        return CycleEntryModel.fromJson(response);
      } else {
        final response = await _supabase
            .from(_table)
            .insert(entry.toJson())
            .select()
            .single();
        return CycleEntryModel.fromJson(response);
      }
    } catch (e) {
      print('Erro ao guardar entrada do ciclo: $e');
      return null;
    }
  }

  /// Remove entrada
  Future<bool> delete(int entryId) async {
    try {
      await _supabase.from(_table).delete().eq('cycle_entry_id', entryId);
      return true;
    } catch (e) {
      print('Erro ao remover entrada do ciclo: $e');
      return false;
    }
  }

  /// Obtém última menstruação registada
  Future<DateTime?> getLastPeriodStart(int visitorId) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .not('flow', 'is', null)
          .order('entry_date', ascending: false)
          .limit(30);

      if ((response as List).isEmpty) return null;

      // Encontrar o início do último período
      DateTime? periodStart;
      DateTime? previousDate;

      for (final entry in response) {
        final entryDate = DateTime.parse(entry['entry_date'] as String);
        
        if (previousDate == null) {
          periodStart = entryDate;
          previousDate = entryDate;
        } else {
          final diff = previousDate.difference(entryDate).inDays;
          if (diff > 2) {
            // Início de um novo período (anterior)
            break;
          }
          periodStart = entryDate;
          previousDate = entryDate;
        }
      }

      return periodStart;
    } catch (e) {
      print('Erro ao obter última menstruação: $e');
      return null;
    }
  }

  /// Calcula duração média do ciclo
  Future<int> getAverageCycleLength(int visitorId) async {
    try {
      // Obter todas as entradas com flow nos últimos 6 meses
      final sixMonthsAgo = DateTime.now().subtract(const Duration(days: 180));
      final entries = await getByDateRange(sixMonthsAgo, DateTime.now(), visitorId);
      
      // Encontrar inícios de períodos
      final periodStarts = <DateTime>[];
      DateTime? currentPeriodStart;
      DateTime? previousDate;

      for (final entry in entries) {
        if (entry.flow != null) {
          if (previousDate == null || entry.entryDate.difference(previousDate).inDays > 2) {
            // Novo período
            currentPeriodStart = entry.entryDate;
            periodStarts.add(currentPeriodStart);
          }
          previousDate = entry.entryDate;
        }
      }

      if (periodStarts.length < 2) return 28; // Default

      // Calcular média
      int totalDays = 0;
      for (int i = 1; i < periodStarts.length; i++) {
        totalDays += periodStarts[i].difference(periodStarts[i - 1]).inDays;
      }

      return totalDays ~/ (periodStarts.length - 1);
    } catch (e) {
      return 28; // Default
    }
  }

  /// Obtém dados do ciclo para calendário mensal
  Future<CycleMonthData> getMonthData(int year, int month, int visitorId) async {
    final startDate = DateTime(year, month, 1);
    final endDate = DateTime(year, month + 1, 0);
    
    final entries = await getByDateRange(startDate, endDate, visitorId);
    final lastPeriod = await getLastPeriodStart(visitorId);
    final avgCycleLength = await getAverageCycleLength(visitorId);

    // Criar mapa de entradas por data
    final entriesByDate = <DateTime, CycleEntryModel>{};
    for (final entry in entries) {
      entriesByDate[entry.entryDate] = entry;
    }

    // Calcular fases previstas
    final phases = <DateTime, CyclePhase>{};
    if (lastPeriod != null) {
      _calculatePhases(phases, lastPeriod, avgCycleLength, startDate, endDate);
    }

    return CycleMonthData(
      year: year,
      month: month,
      entries: entriesByDate,
      predictedPhases: phases,
      lastPeriodStart: lastPeriod,
      averageCycleLength: avgCycleLength,
    );
  }

  void _calculatePhases(
    Map<DateTime, CyclePhase> phases,
    DateTime lastPeriod,
    int cycleLength,
    DateTime startDate,
    DateTime endDate,
  ) {
    // Calcular próximo período previsto
    DateTime nextPeriod = lastPeriod;
    while (nextPeriod.isBefore(endDate)) {
      // Menstruação (dias 1-5)
      for (int i = 0; i < 5; i++) {
        final date = nextPeriod.add(Duration(days: i));
        if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
          phases[date] = CyclePhase.menstruation;
        }
      }

      // Fase folicular (dias 6-13)
      for (int i = 5; i < 13; i++) {
        final date = nextPeriod.add(Duration(days: i));
        if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
          phases[date] = CyclePhase.follicular;
        }
      }

      // Ovulação (dias 14-16)
      for (int i = 13; i < 16; i++) {
        final date = nextPeriod.add(Duration(days: i));
        if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
          phases[date] = CyclePhase.ovulation;
        }
      }

      // Fase lútea (dias 17 até fim do ciclo)
      for (int i = 16; i < cycleLength; i++) {
        final date = nextPeriod.add(Duration(days: i));
        if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
          phases[date] = CyclePhase.luteal;
        }
      }

      nextPeriod = nextPeriod.add(Duration(days: cycleLength));
    }
  }
}

/// Dados do ciclo para um mês
class CycleMonthData {
  final int year;
  final int month;
  final Map<DateTime, CycleEntryModel> entries;
  final Map<DateTime, CyclePhase> predictedPhases;
  final DateTime? lastPeriodStart;
  final int averageCycleLength;

  CycleMonthData({
    required this.year,
    required this.month,
    required this.entries,
    required this.predictedPhases,
    this.lastPeriodStart,
    required this.averageCycleLength,
  });

  /// Obtém fase para uma data (real ou prevista)
  CyclePhase? getPhaseForDate(DateTime date) {
    final entry = entries[DateTime(date.year, date.month, date.day)];
    if (entry?.phase != null) return entry!.phase;
    return predictedPhases[DateTime(date.year, date.month, date.day)];
  }

  /// Verifica se tem menstruação registada numa data
  bool hasPeriodOnDate(DateTime date) {
    final entry = entries[DateTime(date.year, date.month, date.day)];
    return entry?.flow != null;
  }
}
