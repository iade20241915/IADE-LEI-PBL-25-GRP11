import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/habit_model.dart';
import '../interfaces/habit_repository.dart';

/// Implementação Supabase do repositório de hábitos
class SupabaseHabitRepository implements HabitRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _habitsTable = SupabaseConfig.habitsTable;
  static const String _habitLogTable = 'habit_log'; // Tabela para tracking diário

  @override
  Future<List<HabitModel>> getAll(int visitorId) async {
    try {
      final response = await _supabase
          .from(_habitsTable)
          .select()
          .eq('visitor_id', visitorId)
          .order('created_at', ascending: false);

      return (response as List)
          .map((e) => HabitModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao obter hábitos: $e');
      return [];
    }
  }

  @override
  Future<HabitModel?> getById(int habitId) async {
    try {
      final response = await _supabase
          .from(_habitsTable)
          .select()
          .eq('habit_id', habitId)
          .single();

      return HabitModel.fromJson(response);
    } catch (e) {
      print('Erro ao obter hábito: $e');
      return null;
    }
  }

  @override
  Future<HabitModel?> add(HabitModel habit) async {
    try {
      final response = await _supabase
          .from(_habitsTable)
          .insert(habit.toJson())
          .select()
          .single();

      return HabitModel.fromJson(response);
    } catch (e) {
      print('Erro ao adicionar hábito: $e');
      return null;
    }
  }

  @override
  Future<HabitModel?> update(HabitModel habit) async {
    try {
      final response = await _supabase
          .from(_habitsTable)
          .update(habit.toJson())
          .eq('habit_id', habit.habitId)
          .select()
          .single();

      return HabitModel.fromJson(response);
    } catch (e) {
      print('Erro ao atualizar hábito: $e');
      return null;
    }
  }

  @override
  Future<bool> delete(int habitId) async {
    try {
      await _supabase.from(_habitsTable).delete().eq('habit_id', habitId);
      return true;
    } catch (e) {
      print('Erro ao remover hábito: $e');
      return false;
    }
  }

  /// Regista conclusão de hábito para uma data
  Future<bool> logHabit(int habitId, DateTime date, {bool completed = true, String? notes}) async {
    try {
      final dateStr = date.toIso8601String().split('T')[0];
      
      // Verificar se já existe log para esta data
      final existing = await _supabase
          .from(_habitLogTable)
          .select()
          .eq('habit_id', habitId)
          .eq('log_date', dateStr)
          .maybeSingle();

      if (existing != null) {
        // Atualizar
        await _supabase
            .from(_habitLogTable)
            .update({'completed': completed, 'notes': notes})
            .eq('habit_log_id', existing['habit_log_id']);
      } else {
        // Criar
        await _supabase.from(_habitLogTable).insert({
          'habit_id': habitId,
          'log_date': dateStr,
          'completed': completed,
          'notes': notes,
        });
      }

      // Atualizar contadores no hábito
      await _updateHabitCounters(habitId);
      
      return true;
    } catch (e) {
      print('Erro ao registar hábito: $e');
      return false;
    }
  }

  /// Obtém logs de um hábito para um período
  Future<List<HabitLogModel>> getLogs(int habitId, DateTime startDate, DateTime endDate) async {
    try {
      final response = await _supabase
          .from(_habitLogTable)
          .select()
          .eq('habit_id', habitId)
          .gte('log_date', startDate.toIso8601String().split('T')[0])
          .lte('log_date', endDate.toIso8601String().split('T')[0])
          .order('log_date', ascending: true);

      return (response as List)
          .map((e) => HabitLogModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao obter logs: $e');
      return [];
    }
  }

  /// Verifica se hábito foi completado numa data
  Future<bool> isCompletedOnDate(int habitId, DateTime date) async {
    try {
      final response = await _supabase
          .from(_habitLogTable)
          .select()
          .eq('habit_id', habitId)
          .eq('log_date', date.toIso8601String().split('T')[0])
          .eq('completed', true)
          .maybeSingle();

      return response != null;
    } catch (e) {
      return false;
    }
  }

  /// Calcula streak atual de um hábito
  Future<int> calculateCurrentStreak(int habitId) async {
    try {
      final logs = await _supabase
          .from(_habitLogTable)
          .select()
          .eq('habit_id', habitId)
          .eq('completed', true)
          .order('log_date', ascending: false)
          .limit(365);

      if ((logs as List).isEmpty) return 0;

      int streak = 0;
      DateTime? previousDate;

      for (final log in logs) {
        final logDate = DateTime.parse(log['log_date'] as String);
        
        if (previousDate == null) {
          // Primeiro log - verificar se é hoje ou ontem
          final today = DateTime.now();
          final todayDate = DateTime(today.year, today.month, today.day);
          final diff = todayDate.difference(logDate).inDays;
          
          if (diff > 1) break; // Streak quebrado
          streak = 1;
          previousDate = logDate;
        } else {
          final diff = previousDate.difference(logDate).inDays;
          if (diff == 1) {
            streak++;
            previousDate = logDate;
          } else {
            break; // Streak quebrado
          }
        }
      }

      return streak;
    } catch (e) {
      return 0;
    }
  }

  /// Obtém resumo semanal de hábitos
  Future<HabitWeeklySummary> getWeeklySummary(int visitorId, DateTime startDate) async {
    final habits = await getAll(visitorId);
    final endDate = startDate.add(const Duration(days: 6));
    
    final habitProgress = <int, List<bool>>{};
    
    for (final habit in habits) {
      final logs = await getLogs(habit.habitId!, startDate, endDate);
      final completedDates = logs.where((l) => l.completed).map((l) => l.logDate).toSet();
      
      final weekProgress = <bool>[];
      for (int i = 0; i < 7; i++) {
        final date = DateTime(startDate.year, startDate.month, startDate.day + i);
        weekProgress.add(completedDates.contains(date));
      }
      
      habitProgress[habit.habitId!] = weekProgress;
    }

    final totalPossible = habits.length * 7;
    final totalCompleted = habitProgress.values
        .fold<int>(0, (sum, week) => sum + week.where((b) => b).length);
    final completionRate = totalPossible > 0 ? totalCompleted / totalPossible : 0.0;

    return HabitWeeklySummary(
      startDate: startDate,
      habits: habits,
      habitProgress: habitProgress,
      totalCompleted: totalCompleted,
      totalPossible: totalPossible,
      completionRate: completionRate,
    );
  }

  /// Valores para gráfico semanal (taxa de conclusão por dia)
  List<double> getWeeklyChartValues(HabitWeeklySummary summary) {
    final values = <double>[];
    final habitCount = summary.habits.length;
    
    if (habitCount == 0) return List.filled(7, 0.0);
    
    for (int day = 0; day < 7; day++) {
      int completedOnDay = 0;
      for (final progress in summary.habitProgress.values) {
        if (progress[day]) completedOnDay++;
      }
      values.add(completedOnDay / habitCount);
    }
    
    return values;
  }

  // ==================== HELPERS PRIVADOS ====================

  Future<void> _updateHabitCounters(int habitId) async {
    try {
      final streak = await calculateCurrentStreak(habitId);
      
      // Obter hábito atual para comparar longest_streak
      final habit = await getById(habitId);
      if (habit == null) return;

      final longestStreak = streak > habit.longestStreak ? streak : habit.longestStreak;

      await _supabase
          .from(_habitsTable)
          .update({
            'current_streak': streak,
            'longest_streak': longestStreak,
          })
          .eq('habit_id', habitId);
    } catch (e) {
      print('Erro ao atualizar contadores: $e');
    }
  }
}

/// Modelo para log de hábito
class HabitLogModel {
  final int? habitLogId;
  final int habitId;
  final DateTime logDate;
  final bool completed;
  final String? notes;

  HabitLogModel({
    this.habitLogId,
    required this.habitId,
    required this.logDate,
    required this.completed,
    this.notes,
  });

  factory HabitLogModel.fromJson(Map<String, dynamic> json) {
    return HabitLogModel(
      habitLogId: json['habit_log_id'] as int?,
      habitId: json['habit_id'] as int,
      logDate: DateTime.parse(json['log_date'] as String),
      completed: json['completed'] as bool? ?? false,
      notes: json['notes'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
    'habit_id': habitId,
    'log_date': logDate.toIso8601String().split('T')[0],
    'completed': completed,
    'notes': notes,
  };
}

/// Resumo semanal de hábitos
class HabitWeeklySummary {
  final DateTime startDate;
  final List<HabitModel> habits;
  final Map<int, List<bool>> habitProgress; // habitId -> [seg, ter, qua, ...]
  final int totalCompleted;
  final int totalPossible;
  final double completionRate;

  HabitWeeklySummary({
    required this.startDate,
    required this.habits,
    required this.habitProgress,
    required this.totalCompleted,
    required this.totalPossible,
    required this.completionRate,
  });

  String get completionPercentage => '${(completionRate * 100).toStringAsFixed(0)}%';
}
