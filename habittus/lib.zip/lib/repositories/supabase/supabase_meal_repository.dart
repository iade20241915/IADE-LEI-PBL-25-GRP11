import '../../core/database/supabase_service.dart';
import '../../models/meal_model.dart';
import '../interfaces/repository_interfaces.dart';

/// Implementação Supabase do repositório de refeições
class SupabaseMealRepository implements IMealRepository {
  final SupabaseService _supabase = SupabaseService.instance;

  static const String _mealTable = 'meal';
  static const String _mealItemTable = 'meal_item';
  static const String _foodTable = 'food';

  @override
  Future<MealModel?> getById(int id) async {
    try {
      final response = await _supabase
          .from(_mealTable)
          .select('''
            *,
            meal_items:meal_item(
              *,
              food:food(*)
            )
          ''')
          .eq('meal_id', id)
          .single();
      return MealModel.fromJson(response);
    } catch (e) {
      return null;
    }
  }

  @override
  Future<List<MealModel>> getAll() async {
    final response = await _supabase.from(_mealTable).select('''
      *,
      meal_items:meal_item(
        *,
        food:food(*)
      )
    ''');
    return (response as List).map((e) => MealModel.fromJson(e)).toList();
  }

  @override
  Future<MealModel> create(MealModel entity) async {
    final response = await _supabase
        .from(_mealTable)
        .insert(entity.toJson())
        .select()
        .single();
    return MealModel.fromJson(response);
  }

  @override
  Future<MealModel> update(MealModel entity) async {
    final response = await _supabase
        .from(_mealTable)
        .update(entity.toJson())
        .eq('meal_id', entity.mealId!)
        .select()
        .single();
    return MealModel.fromJson(response);
  }

  @override
  Future<bool> delete(int id) async {
    try {
      // Primeiro remover os items
      await _supabase.from(_mealItemTable).delete().eq('meal_id', id);
      // Depois remover a refeição
      await _supabase.from(_mealTable).delete().eq('meal_id', id);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  Future<List<MealModel>> getByDate(int userId, DateTime date) async {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final response = await _supabase.from(_mealTable).select('''
      *,
      meal_items:meal_item(
        *,
        food:food(*)
      )
    ''')
        .eq('user_id', userId)
        .gte('created_at', startOfDay.toIso8601String())
        .lt('created_at', endOfDay.toIso8601String())
        .order('created_at', ascending: true);

    return (response as List).map((e) => MealModel.fromJson(e)).toList();
  }

  @override
  Future<List<MealModel>> getByDateRange(
      int userId, DateTime start, DateTime end) async {
    final response = await _supabase.from(_mealTable).select('''
      *,
      meal_items:meal_item(
        *,
        food:food(*)
      )
    ''')
        .eq('user_id', userId)
        .gte('created_at', start.toIso8601String())
        .lte('created_at', end.toIso8601String())
        .order('created_at', ascending: true);

    return (response as List).map((e) => MealModel.fromJson(e)).toList();
  }

  @override
  Future<DailyCaloriesSummary> getDailySummary(int userId, DateTime date) async {
    final meals = await getByDate(userId, date);

    return DailyCaloriesSummary(
      date: date,
      meals: meals,
    );
  }

  @override
  Future<MealModel> addMeal(MealModel meal) async {
    // Criar a refeição
    final createdMeal = await create(meal);

    // Adicionar os items se houver
    if (meal.items.isNotEmpty) {
      for (final item in meal.items) {
        await addMealItem(createdMeal.mealId!, item);
      }
    }

    // Retornar refeição completa
    return (await getById(createdMeal.mealId!))!;
  }

  @override
  Future<MealItemModel> addMealItem(int mealId, MealItemModel item) async {
    final data = item.toJson();
    data['meal_id'] = mealId;

    final response = await _supabase
        .from(_mealItemTable)
        .insert(data)
        .select('''
          *,
          food:food(*)
        ''')
        .single();

    return MealItemModel.fromJson(response);
  }

  @override
  Future<bool> removeMealItem(int mealItemId) async {
    try {
      await _supabase
          .from(_mealItemTable)
          .delete()
          .eq('meal_item_id', mealItemId);
      return true;
    } catch (e) {
      return false;
    }
  }
}

/// Implementação Supabase do repositório de alimentos
class SupabaseFoodRepository implements IFoodRepository {
  final SupabaseService _supabase = SupabaseService.instance;

  static const String _tableName = 'food';

  @override
  Future<FoodModel?> getById(int id) async {
    try {
      final response = await _supabase
          .from(_tableName)
          .select()
          .eq('food_id', id)
          .single();
      return FoodModel.fromJson(response);
    } catch (e) {
      return null;
    }
  }

  @override
  Future<List<FoodModel>> getAll() async {
    final response = await _supabase.from(_tableName).select();
    return (response as List).map((e) => FoodModel.fromJson(e)).toList();
  }

  @override
  Future<FoodModel> create(FoodModel entity) async {
    final response = await _supabase
        .from(_tableName)
        .insert(entity.toJson())
        .select()
        .single();
    return FoodModel.fromJson(response);
  }

  @override
  Future<FoodModel> update(FoodModel entity) async {
    final response = await _supabase
        .from(_tableName)
        .update(entity.toJson())
        .eq('food_id', entity.foodId!)
        .select()
        .single();
    return FoodModel.fromJson(response);
  }

  @override
  Future<bool> delete(int id) async {
    try {
      await _supabase.from(_tableName).delete().eq('food_id', id);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  Future<List<FoodModel>> search(String query) async {
    final response = await _supabase
        .from(_tableName)
        .select()
        .ilike('name', '%$query%')
        .limit(20);

    return (response as List).map((e) => FoodModel.fromJson(e)).toList();
  }

  @override
  Future<List<FoodModel>> getPopular() async {
    // TODO: Implementar com base em frequência de uso
    final response = await _supabase.from(_tableName).select().limit(20);
    return (response as List).map((e) => FoodModel.fromJson(e)).toList();
  }

  @override
  Future<List<FoodModel>> getRecent(int userId) async {
    // Buscar alimentos usados recentemente pelo utilizador
    final response = await _supabase.from('meal_item').select('''
      food:food(*)
    ''')
        .order('meal_item_id', ascending: false)
        .limit(10);

    final foods = <FoodModel>[];
    final seenIds = <int>{};

    for (final item in response) {
      if (item['food'] != null) {
        final food = FoodModel.fromJson(item['food']);
        if (food.foodId != null && !seenIds.contains(food.foodId)) {
          seenIds.add(food.foodId!);
          foods.add(food);
        }
      }
    }

    return foods;
  }
}
