import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/meal_model.dart';

/// Implementação Supabase do repositório de refeições
class SupabaseMealRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _mealTable = SupabaseConfig.mealTable;
  static const String _mealItemTable = SupabaseConfig.mealItemTable;
  static const String _foodTable = SupabaseConfig.foodTable;

  /// Obtém refeições de uma data
  Future<List<MealModel>> getByDate(DateTime date, int visitorId) async {
    try {
      final response = await _supabase
          .from(_mealTable)
          .select()
          .eq('visitor_id', visitorId)
          .eq('meal_date', date.toIso8601String().split('T')[0])
          .order('meal_time', ascending: true);

      final meals = <MealModel>[];
      for (final data in response as List) {
        final items = await _getMealItems(data['meal_id'] as int);
        meals.add(MealModel.fromJson(data, items));
      }
      
      return meals;
    } catch (e) {
      print('Erro ao obter refeições: $e');
      return [];
    }
  }

  /// Adiciona uma refeição
  Future<MealModel?> add(MealModel meal) async {
    try {
      final mealData = {
        'visitor_id': meal.visitorId,
        'meal_type': meal.mealType.name,
        'meal_date': meal.mealDate.toIso8601String().split('T')[0],
        'meal_time': meal.mealTime,
        'notes': meal.notes,
      };

      final response = await _supabase
          .from(_mealTable)
          .insert(mealData)
          .select()
          .single();

      final mealId = response['meal_id'] as int;

      // Adicionar itens
      for (final item in meal.items) {
        await _addMealItem(mealId, item);
      }

      return MealModel.fromJson(response, meal.items);
    } catch (e) {
      print('Erro ao adicionar refeição: $e');
      return null;
    }
  }

  /// Remove uma refeição
  Future<bool> delete(int mealId) async {
    try {
      // Itens são removidos por CASCADE
      await _supabase.from(_mealTable).delete().eq('meal_id', mealId);
      return true;
    } catch (e) {
      print('Erro ao remover refeição: $e');
      return false;
    }
  }

  /// Obtém resumo diário de calorias
  Future<DailyCaloriesSummary> getDailySummary(DateTime date, int visitorId) async {
    final meals = await getByDate(date, visitorId);
    
    int totalCalories = 0;
    int totalProtein = 0;
    int totalCarbs = 0;
    int totalFat = 0;

    final mealCalories = <MealType, int>{};
    for (final type in MealType.values) {
      mealCalories[type] = 0;
    }

    for (final meal in meals) {
      final mealCal = meal.totalCalories;
      totalCalories += mealCal;
      mealCalories[meal.mealType] = (mealCalories[meal.mealType] ?? 0) + mealCal;
      
      for (final item in meal.items) {
        totalProtein += item.protein?.toInt() ?? 0;
        totalCarbs += item.carbs?.toInt() ?? 0;
        totalFat += item.fat?.toInt() ?? 0;
      }
    }

    return DailyCaloriesSummary(
      date: date,
      totalCalories: totalCalories,
      totalProtein: totalProtein,
      totalCarbs: totalCarbs,
      totalFat: totalFat,
      mealCount: meals.length,
      caloriesByMealType: mealCalories,
      meals: meals,
    );
  }

  /// Obtém resumo semanal para gráfico
  Future<MealWeeklySummary> getWeeklySummary(DateTime startDate, int visitorId) async {
    final dailySummaries = <DateTime, DailyCaloriesSummary>{};
    
    for (int i = 0; i < 7; i++) {
      final date = DateTime(startDate.year, startDate.month, startDate.day + i);
      dailySummaries[date] = await getDailySummary(date, visitorId);
    }

    final totalCalories = dailySummaries.values.fold<int>(
      0, (sum, s) => sum + s.totalCalories
    );
    final avgCalories = totalCalories ~/ 7;

    return MealWeeklySummary(
      startDate: startDate,
      dailySummaries: dailySummaries,
      totalCalories: totalCalories,
      averageCalories: avgCalories,
    );
  }

  /// Calcula valores normalizados para gráfico (0.0 a 1.0, meta = 2000 kcal)
  List<double> getWeeklyChartValues(MealWeeklySummary summary) {
    final values = <double>[];
    final sortedDates = summary.dailySummaries.keys.toList()..sort();
    
    for (final date in sortedDates) {
      final dailySummary = summary.dailySummaries[date];
      final calories = dailySummary?.totalCalories ?? 0;
      // Normalizar para 2000 kcal
      values.add((calories / 2000).clamp(0.0, 1.5));
    }
    
    return values;
  }

  /// Pesquisa alimentos
  Future<List<FoodModel>> searchFood(String query) async {
    try {
      final response = await _supabase
          .from(_foodTable)
          .select()
          .ilike('food_name', '%$query%')
          .limit(20);

      return (response as List)
          .map((e) => FoodModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao pesquisar alimentos: $e');
      return [];
    }
  }

  // ==================== HELPERS PRIVADOS ====================

  Future<List<MealItemModel>> _getMealItems(int mealId) async {
    try {
      final response = await _supabase
          .from(_mealItemTable)
          .select('*, food:food_id(*)')
          .eq('meal_id', mealId);

      return (response as List).map((e) {
        final food = e['food'] != null ? FoodModel.fromJson(e['food']) : null;
        return MealItemModel.fromJson(e, food);
      }).toList();
    } catch (e) {
      print('Erro ao obter itens da refeição: $e');
      return [];
    }
  }

  Future<void> _addMealItem(int mealId, MealItemModel item) async {
    await _supabase.from(_mealItemTable).insert({
      'meal_id': mealId,
      'food_id': item.foodId,
      'quantity': item.quantity,
      'unit': item.unit,
      'kcal': item.kcal,
      'protein_g': item.protein,
      'carbs_g': item.carbs,
      'fat_g': item.fat,
    });
  }
}

/// Resumo diário de calorias
class DailyCaloriesSummary {
  final DateTime date;
  final int totalCalories;
  final int totalProtein;
  final int totalCarbs;
  final int totalFat;
  final int mealCount;
  final Map<MealType, int> caloriesByMealType;
  final List<MealModel> meals;

  DailyCaloriesSummary({
    required this.date,
    required this.totalCalories,
    required this.totalProtein,
    required this.totalCarbs,
    required this.totalFat,
    required this.mealCount,
    required this.caloriesByMealType,
    required this.meals,
  });

  /// Valor normalizado para gráfico (0.0 a 1.0, meta = 2000 kcal)
  double get normalizedValue => (totalCalories / 2000).clamp(0.0, 1.5);
}

/// Resumo semanal de refeições
class MealWeeklySummary {
  final DateTime startDate;
  final Map<DateTime, DailyCaloriesSummary> dailySummaries;
  final int totalCalories;
  final int averageCalories;

  MealWeeklySummary({
    required this.startDate,
    required this.dailySummaries,
    required this.totalCalories,
    required this.averageCalories,
  });
}
