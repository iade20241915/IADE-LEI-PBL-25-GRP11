import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/mood_model.dart';
import '../interfaces/mood_repository.dart';

/// Implementação Supabase do repositório de humor
class SupabaseMoodRepository implements MoodRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _table = SupabaseConfig.moodTable;

  @override
  Future<MoodModel?> getByDate(DateTime date, int visitorId) async {
    try {
      final startOfDay = DateTime(date.year, date.month, date.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .gte('mood_date', startOfDay.toIso8601String().split('T')[0])
          .lte('mood_date', endOfDay.toIso8601String().split('T')[0])
          .maybeSingle();

      if (response == null) return null;
      return MoodModel.fromJson(response);
    } catch (e) {
      print('Erro ao obter humor: $e');
      return null;
    }
  }

  @override
  Future<MoodModel?> save(MoodModel mood) async {
    try {
      // Verificar se já existe registo para esta data
      final existing = await getByDate(mood.moodDate, mood.visitorId);
      
      if (existing != null) {
        // Atualizar existente
        final response = await _supabase
            .from(_table)
            .update(mood.toJson())
            .eq('mood_id', existing.moodId)
            .select()
            .single();
        return MoodModel.fromJson(response);
      } else {
        // Criar novo
        final response = await _supabase
            .from(_table)
            .insert(mood.toJson())
            .select()
            .single();
        return MoodModel.fromJson(response);
      }
    } catch (e) {
      print('Erro ao guardar humor: $e');
      return null;
    }
  }

  @override
  Future<bool> delete(int id) async {
    try {
      await _supabase.from(_table).delete().eq('mood_id', id);
      return true;
    } catch (e) {
      print('Erro ao remover humor: $e');
      return false;
    }
  }

  /// Obtém registos de humor de um período
  Future<List<MoodModel>> getByDateRange(
    DateTime startDate,
    DateTime endDate,
    int visitorId,
  ) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .gte('mood_date', startDate.toIso8601String().split('T')[0])
          .lte('mood_date', endDate.toIso8601String().split('T')[0])
          .order('mood_date', ascending: true);

      return (response as List)
          .map((e) => MoodModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao obter registos de humor: $e');
      return [];
    }
  }

  /// Obtém resumo semanal para gráfico
  Future<MoodWeeklySummary> getWeeklySummary(DateTime startDate, int visitorId) async {
    final endDate = startDate.add(const Duration(days: 6));
    final moods = await getByDateRange(startDate, endDate, visitorId);
    
    final dailyData = <DateTime, MoodModel?>{};
    
    for (int i = 0; i < 7; i++) {
      final date = DateTime(startDate.year, startDate.month, startDate.day + i);
      dailyData[date] = null;
    }
    
    for (final mood in moods) {
      final date = DateTime(mood.moodDate.year, mood.moodDate.month, mood.moodDate.day);
      dailyData[date] = mood;
    }

    final avgLevel = moods.isNotEmpty
        ? moods.fold<int>(0, (sum, m) => sum + m.moodLevel.value) ~/ moods.length
        : 3;

    return MoodWeeklySummary(
      startDate: startDate,
      moods: moods,
      dailyData: dailyData,
      averageLevel: avgLevel,
      daysRegistered: moods.length,
    );
  }

  /// Calcula valores normalizados para gráfico (0.0 a 1.0)
  List<double> getWeeklyChartValues(MoodWeeklySummary summary) {
    final values = <double>[];
    final sortedDates = summary.dailyData.keys.toList()..sort();
    
    for (final date in sortedDates) {
      final mood = summary.dailyData[date];
      if (mood != null) {
        // Normalizar de 1-5 para 0.0-1.0
        values.add((mood.moodLevel.value - 1) / 4);
      } else {
        values.add(0.0);
      }
    }
    
    return values;
  }
}

/// Resumo semanal de humor
class MoodWeeklySummary {
  final DateTime startDate;
  final List<MoodModel> moods;
  final Map<DateTime, MoodModel?> dailyData;
  final int averageLevel;
  final int daysRegistered;

  MoodWeeklySummary({
    required this.startDate,
    required this.moods,
    required this.dailyData,
    required this.averageLevel,
    required this.daysRegistered,
  });

  MoodLevel get averageMoodLevel => MoodLevel.values[averageLevel.clamp(1, 5) - 1];
}
