import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/sleep_session_model.dart';
import '../interfaces/sleep_repository.dart';

/// Implementação Supabase do repositório de sono
class SupabaseSleepRepository implements SleepRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _table = SupabaseConfig.sleepSessionTable;

  @override
  Future<SleepSessionModel?> getByDate(DateTime date, int visitorId) async {
    try {
      final startOfDay = DateTime(date.year, date.month, date.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .gte('sleep_date', startOfDay.toIso8601String().split('T')[0])
          .lte('sleep_date', endOfDay.toIso8601String().split('T')[0])
          .maybeSingle();

      if (response == null) return null;
      return SleepSessionModel.fromJson(response);
    } catch (e) {
      print('Erro ao obter sessão de sono: $e');
      return null;
    }
  }

  @override
  Future<SleepSessionModel?> save(SleepSessionModel session) async {
    try {
      // Verificar se já existe registo para esta data
      final existing = await getByDate(session.sleepDate, session.visitorId);
      
      if (existing != null) {
        // Atualizar existente
        final response = await _supabase
            .from(_table)
            .update(session.toJson())
            .eq('sleep_session_id', existing.sleepSessionId)
            .select()
            .single();
        return SleepSessionModel.fromJson(response);
      } else {
        // Criar novo
        final response = await _supabase
            .from(_table)
            .insert(session.toJson())
            .select()
            .single();
        return SleepSessionModel.fromJson(response);
      }
    } catch (e) {
      print('Erro ao guardar sessão de sono: $e');
      return null;
    }
  }

  @override
  Future<bool> delete(int id) async {
    try {
      await _supabase.from(_table).delete().eq('sleep_session_id', id);
      return true;
    } catch (e) {
      print('Erro ao remover sessão de sono: $e');
      return false;
    }
  }

  /// Obtém sessões de sono de um período
  Future<List<SleepSessionModel>> getByDateRange(
    DateTime startDate,
    DateTime endDate,
    int visitorId,
  ) async {
    try {
      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .gte('sleep_date', startDate.toIso8601String().split('T')[0])
          .lte('sleep_date', endDate.toIso8601String().split('T')[0])
          .order('sleep_date', ascending: true);

      return (response as List)
          .map((e) => SleepSessionModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao obter sessões de sono: $e');
      return [];
    }
  }

  /// Obtém resumo semanal para gráfico
  Future<SleepWeeklySummary> getWeeklySummary(DateTime startDate, int visitorId) async {
    final endDate = startDate.add(const Duration(days: 6));
    final sessions = await getByDateRange(startDate, endDate, visitorId);
    
    final dailyData = <DateTime, SleepSessionModel?>{};
    
    for (int i = 0; i < 7; i++) {
      final date = DateTime(startDate.year, startDate.month, startDate.day + i);
      dailyData[date] = null;
    }
    
    for (final session in sessions) {
      final date = DateTime(session.sleepDate.year, session.sleepDate.month, session.sleepDate.day);
      dailyData[date] = session;
    }

    final totalMinutes = sessions.fold<int>(0, (sum, s) => sum + s.durationMinutes);
    final avgMinutes = sessions.isNotEmpty ? totalMinutes ~/ sessions.length : 0;
    final avgQuality = sessions.isNotEmpty
        ? sessions.fold<int>(0, (sum, s) => sum + s.qualityScore) ~/ sessions.length
        : 0;

    return SleepWeeklySummary(
      startDate: startDate,
      sessions: sessions,
      dailyData: dailyData,
      averageMinutes: avgMinutes,
      averageQuality: avgQuality,
      totalNights: sessions.length,
    );
  }

  /// Calcula valores normalizados para gráfico (0.0 a 1.0, meta = 8h)
  List<double> getWeeklyChartValues(SleepWeeklySummary summary) {
    final values = <double>[];
    final sortedDates = summary.dailyData.keys.toList()..sort();
    
    for (final date in sortedDates) {
      final session = summary.dailyData[date];
      if (session != null) {
        // Normalizar para 8 horas (480 minutos)
        values.add((session.durationMinutes / 480).clamp(0.0, 1.5));
      } else {
        values.add(0.0);
      }
    }
    
    return values;
  }
}

/// Resumo semanal de sono
class SleepWeeklySummary {
  final DateTime startDate;
  final List<SleepSessionModel> sessions;
  final Map<DateTime, SleepSessionModel?> dailyData;
  final int averageMinutes;
  final int averageQuality;
  final int totalNights;

  SleepWeeklySummary({
    required this.startDate,
    required this.sessions,
    required this.dailyData,
    required this.averageMinutes,
    required this.averageQuality,
    required this.totalNights,
  });

  String get averageFormatted {
    final hours = averageMinutes ~/ 60;
    final minutes = averageMinutes % 60;
    return '${hours}h${minutes.toString().padLeft(2, '0')}';
  }
}
