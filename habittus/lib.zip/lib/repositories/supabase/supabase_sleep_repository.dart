import '../../core/database/supabase_service.dart';
import '../../models/sleep_session_model.dart';
import '../interfaces/repository_interfaces.dart';

/// Implementação Supabase do repositório de sessões de sono
class SupabaseSleepSessionRepository implements ISleepSessionRepository {
  final SupabaseService _supabase = SupabaseService.instance;

  static const String _tableName = 'sleep_session';

  @override
  Future<SleepSessionModel?> getById(int id) async {
    try {
      final response = await _supabase
          .from(_tableName)
          .select()
          .eq('sleep_session_id', id)
          .single();
      return SleepSessionModel.fromJson(response);
    } catch (e) {
      return null;
    }
  }

  @override
  Future<List<SleepSessionModel>> getAll() async {
    final response = await _supabase.from(_tableName).select();
    return (response as List)
        .map((e) => SleepSessionModel.fromJson(e))
        .toList();
  }

  @override
  Future<SleepSessionModel> create(SleepSessionModel entity) async {
    final response = await _supabase
        .from(_tableName)
        .insert(entity.toJson())
        .select()
        .single();
    return SleepSessionModel.fromJson(response);
  }

  @override
  Future<SleepSessionModel> update(SleepSessionModel entity) async {
    final response = await _supabase
        .from(_tableName)
        .update(entity.toJson())
        .eq('sleep_session_id', entity.sleepSessionId!)
        .select()
        .single();
    return SleepSessionModel.fromJson(response);
  }

  @override
  Future<bool> delete(int id) async {
    try {
      await _supabase
          .from(_tableName)
          .delete()
          .eq('sleep_session_id', id);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  Future<SleepSessionModel?> getByDate(int userId, DateTime date) async {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    try {
      final response = await _supabase
          .from(_tableName)
          .select()
          .eq('user_id', userId)
          .gte('start_time', startOfDay.toIso8601String())
          .lt('start_time', endOfDay.toIso8601String())
          .order('start_time', ascending: false)
          .limit(1)
          .single();
      return SleepSessionModel.fromJson(response);
    } catch (e) {
      return null;
    }
  }

  @override
  Future<List<SleepSessionModel>> getByDateRange(
      int userId, DateTime start, DateTime end) async {
    final response = await _supabase
        .from(_tableName)
        .select()
        .eq('user_id', userId)
        .gte('start_time', start.toIso8601String())
        .lte('start_time', end.toIso8601String())
        .order('start_time', ascending: true);

    return (response as List)
        .map((e) => SleepSessionModel.fromJson(e))
        .toList();
  }

  @override
  Future<SleepWeeklySummary> getWeeklySummary(
      int userId, DateTime weekStart) async {
    final weekEnd = weekStart.add(const Duration(days: 7));
    final sessions = await getByDateRange(userId, weekStart, weekEnd);

    return SleepWeeklySummary(
      weekStart: weekStart,
      sessions: sessions,
    );
  }

  @override
  Future<SleepSessionModel> saveSleep(
      int userId, Duration duration, int qualityScore, DateTime date) async {
    // Verificar se já existe registo para este dia
    final existing = await getByDate(userId, date);

    final session = SleepSessionModel.fromDuration(
      duration: duration,
      userId: userId,
      qualityScore: qualityScore,
      date: date,
    );

    if (existing != null) {
      // Atualizar existente
      return update(session.copyWith(sleepSessionId: existing.sleepSessionId));
    } else {
      // Criar novo
      return create(session);
    }
  }
}
