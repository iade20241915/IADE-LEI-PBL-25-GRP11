import '../../core/database/supabase_service.dart';
import '../../models/water_intake_model.dart';
import '../interfaces/repository_interfaces.dart';

/// Implementação Supabase do repositório de consumo de água
class SupabaseWaterIntakeRepository implements IWaterIntakeRepository {
  final SupabaseService _supabase = SupabaseService.instance;

  static const String _tableName = 'water_intake';

  @override
  Future<WaterIntakeModel?> getById(int id) async {
    try {
      final response = await _supabase
          .from(_tableName)
          .select()
          .eq('water_intake_id', id)
          .single();
      return WaterIntakeModel.fromJson(response);
    } catch (e) {
      return null;
    }
  }

  @override
  Future<List<WaterIntakeModel>> getAll() async {
    final response = await _supabase.from(_tableName).select();
    return (response as List)
        .map((e) => WaterIntakeModel.fromJson(e))
        .toList();
  }

  @override
  Future<WaterIntakeModel> create(WaterIntakeModel entity) async {
    final response = await _supabase
        .from(_tableName)
        .insert(entity.toJson())
        .select()
        .single();
    return WaterIntakeModel.fromJson(response);
  }

  @override
  Future<WaterIntakeModel> update(WaterIntakeModel entity) async {
    final response = await _supabase
        .from(_tableName)
        .update(entity.toJson())
        .eq('water_intake_id', entity.waterIntakeId!)
        .select()
        .single();
    return WaterIntakeModel.fromJson(response);
  }

  @override
  Future<bool> delete(int id) async {
    try {
      await _supabase
          .from(_tableName)
          .delete()
          .eq('water_intake_id', id);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  Future<List<WaterIntakeModel>> getByDate(int userId, DateTime date) async {
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    final response = await _supabase
        .from(_tableName)
        .select()
        .eq('user_id', userId)
        .gte('intake_at', startOfDay.toIso8601String())
        .lt('intake_at', endOfDay.toIso8601String())
        .order('intake_at', ascending: true);

    return (response as List)
        .map((e) => WaterIntakeModel.fromJson(e))
        .toList();
  }

  @override
  Future<List<WaterIntakeModel>> getByDateRange(
      int userId, DateTime start, DateTime end) async {
    final response = await _supabase
        .from(_tableName)
        .select()
        .eq('user_id', userId)
        .gte('intake_at', start.toIso8601String())
        .lte('intake_at', end.toIso8601String())
        .order('intake_at', ascending: true);

    return (response as List)
        .map((e) => WaterIntakeModel.fromJson(e))
        .toList();
  }

  @override
  Future<WaterDailySummary> getDailySummary(int userId, DateTime date) async {
    final intakes = await getByDate(userId, date);
    final totalMl = intakes.fold<int>(0, (sum, i) => sum + i.amountMl);

    return WaterDailySummary(
      date: date,
      totalMl: totalMl,
      intakes: intakes,
    );
  }

  @override
  Future<int> getTotalForDate(int userId, DateTime date) async {
    final intakes = await getByDate(userId, date);
    return intakes.fold<int>(0, (sum, i) => sum + i.amountMl);
  }

  @override
  Future<WaterIntakeModel> addIntake(
      int userId, int amountMl, WaterSource source) async {
    final intake = WaterIntakeModel(
      amountMl: amountMl,
      source: source,
      userId: userId,
    );
    return create(intake);
  }
}
