import '../../core/database/supabase_service.dart';
import '../../core/database/supabase_config.dart';
import '../../models/water_intake_model.dart';
import '../interfaces/water_repository.dart';

/// Implementação Supabase do repositório de consumo de água
class SupabaseWaterRepository implements WaterRepository {
  final SupabaseService _supabase = SupabaseService.instance;
  static const String _table = SupabaseConfig.waterIntakeTable;

  @override
  Future<List<WaterIntakeModel>> getByDate(DateTime date, int visitorId) async {
    try {
      final startOfDay = DateTime(date.year, date.month, date.day);
      final endOfDay = startOfDay.add(const Duration(days: 1));

      final response = await _supabase
          .from(_table)
          .select()
          .eq('visitor_id', visitorId)
          .gte('intake_time', startOfDay.toIso8601String())
          .lt('intake_time', endOfDay.toIso8601String())
          .order('intake_time', ascending: true);

      return (response as List)
          .map((e) => WaterIntakeModel.fromJson(e))
          .toList();
    } catch (e) {
      print('Erro ao obter consumo de água: $e');
      return [];
    }
  }

  @override
  Future<WaterIntakeModel?> add(WaterIntakeModel intake) async {
    try {
      final response = await _supabase
          .from(_table)
          .insert(intake.toJson())
          .select()
          .single();

      return WaterIntakeModel.fromJson(response);
    } catch (e) {
      print('Erro ao adicionar consumo de água: $e');
      return null;
    }
  }

  @override
  Future<bool> delete(int id) async {
    try {
      await _supabase.from(_table).delete().eq('water_intake_id', id);
      return true;
    } catch (e) {
      print('Erro ao remover consumo de água: $e');
      return false;
    }
  }

  @override
  Future<WaterIntakeModel?> update(WaterIntakeModel intake) async {
    try {
      final response = await _supabase
          .from(_table)
          .update(intake.toJson())
          .eq('water_intake_id', intake.waterIntakeId)
          .select()
          .single();

      return WaterIntakeModel.fromJson(response);
    } catch (e) {
      print('Erro ao atualizar consumo de água: $e');
      return null;
    }
  }

  /// Obtém resumo diário de consumo de água
  Future<WaterDailySummary> getDailySummary(DateTime date, int visitorId) async {
    final intakes = await getByDate(date, visitorId);
    
    final totalMl = intakes.fold<int>(0, (sum, intake) => sum + intake.amountMl);
    final count = intakes.length;

    return WaterDailySummary(
      date: date,
      totalMl: totalMl,
      count: count,
      intakes: intakes,
    );
  }

  /// Obtém dados para gráfico semanal
  Future<List<WaterDailySummary>> getWeeklySummary(DateTime startDate, int visitorId) async {
    final summaries = <WaterDailySummary>[];
    
    for (int i = 0; i < 7; i++) {
      final date = startDate.add(Duration(days: i));
      final summary = await getDailySummary(date, visitorId);
      summaries.add(summary);
    }
    
    return summaries;
  }

  /// Obtém progresso em relação à meta diária
  Future<double> getDailyProgress(DateTime date, int visitorId, {int goalMl = 2000}) async {
    final summary = await getDailySummary(date, visitorId);
    return summary.totalMl / goalMl;
  }
}

/// Resumo diário de consumo de água
class WaterDailySummary {
  final DateTime date;
  final int totalMl;
  final int count;
  final List<WaterIntakeModel> intakes;

  WaterDailySummary({
    required this.date,
    required this.totalMl,
    required this.count,
    required this.intakes,
  });

  double get totalLiters => totalMl / 1000;
  
  /// Valor normalizado para gráfico (0.0 a 1.0, meta = 2000ml)
  double get normalizedValue => (totalMl / 2000).clamp(0.0, 1.5);
}
