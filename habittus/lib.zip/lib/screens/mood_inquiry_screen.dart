import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/mood_controller.dart';
import '../models/mood.dart';
import '../widgets/date_pills.dart';
import '../widgets/habittus_app_bar.dart';
import '../widgets/habittus_card.dart';
import '../widgets/primary_button.dart';
import '../widgets/habittus_drawer.dart';
import '../screens/mood_inquiry2_screen.dart';

class MoodInquiryScreen extends StatefulWidget {
  const MoodInquiryScreen({super.key});

  @override
  State<MoodInquiryScreen> createState() => _MoodInquiryScreenState();
}

class _MoodInquiryScreenState extends State<MoodInquiryScreen> {
  late DateTime d;

  String get monthName => const [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
  ][d.month - 1];

  @override
  void initState() {
    super.initState();
    d = DateTime.now();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MoodController>().load(_dateOnly(d));
    });
  }

  DateTime _dateOnly(DateTime x) => DateTime(x.year, x.month, x.day);

  void _setDate(DateTime newDate) {
    final nd = _dateOnly(newDate);
    setState(() => d = nd);
    context.read<MoodController>().load(nd);
  }

  DateTime _safeMonthShift(DateTime date, int deltaMonths) {
    final targetMonth = DateTime(date.year, date.month + deltaMonths, 1);
    final lastDayOfTargetMonth = DateTime(
      targetMonth.year,
      targetMonth.month + 1,
      0,
    ).day;

    final day = date.day.clamp(1, lastDayOfTargetMonth);
    return DateTime(targetMonth.year, targetMonth.month, day);
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<MoodController>();

    return Scaffold(
      drawer: const HabittusDrawer(userName: 'USER_NAME'),
      appBar: const HabittusAppBar(showBack: true),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DatePills(
              day: '${d.day}',
              month: monthName,
              year: '${d.year}',
              onDayPrev: () => _setDate(d.subtract(const Duration(days: 1))),
              onDayNext: () => _setDate(d.add(const Duration(days: 1))),
              onMonthPrev: () => _setDate(_safeMonthShift(d, -1)),
              onMonthNext: () => _setDate(_safeMonthShift(d, 1)),
              onYearPrev: () => _setDate(DateTime(d.year - 1, d.month, d.day)),
              onYearNext: () => _setDate(DateTime(d.year + 1, d.month, d.day)),
            ),
            const SizedBox(height: 24),

            HabittusCard(
              title: 'Como te sentes hoje?',
              subtitle: 'Seleciona uma opção',
              child: Align(
                alignment: Alignment.center, // 👈 centra horizontalmente
                child: _MoodGrid(
                  selected: controller.selected,
                  onSelect: controller.select,
                ),
              ),
            ),

            const SizedBox(height: 32),

            Center(
              child: PrimaryButton(
                text: 'Continuar',
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const MoodInquiry2Screen(),
                    ),
                  );
                },

                /*
                controller.selected == null
                    ? null
                    : () async {
                        // Se tiveres submit real no controller, o ideal é:
                        // await controller.submit(date: d);

                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const MoodInquiry2Screen(),
                          ),
                        );
                      },*/
                width: 140,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MoodGrid extends StatelessWidget {
  final MoodLevel? selected;
  final ValueChanged<MoodLevel> onSelect;

  const _MoodGrid({required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    final items = <({MoodLevel level, String label, IconData icon})>[
      (
        level: MoodLevel.veryBad,
        label: 'Muito mal',
        icon: Icons.sentiment_very_dissatisfied,
      ),
      (level: MoodLevel.bad, label: 'Mal', icon: Icons.sentiment_dissatisfied),
      (
        level: MoodLevel.neutral,
        label: 'Neutro',
        icon: Icons.sentiment_neutral,
      ),
      (level: MoodLevel.good, label: 'Bem', icon: Icons.sentiment_satisfied),
      (
        level: MoodLevel.veryGood,
        label: 'Muito bem',
        icon: Icons.sentiment_very_satisfied,
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        // largura mínima de cada botão (ajusta se quiseres)
        const double minButtonWidth = 120;

        return Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: items.map((it) {
            final isSelected = selected == it.level;

            return ConstrainedBox(
              constraints: BoxConstraints(
                minWidth: minButtonWidth,
                maxWidth: constraints.maxWidth,
              ),
              child: Material(
                color: isSelected
                    ? const Color(0xFFBFDFA8)
                    : const Color(0xFFEAF3E3),
                borderRadius: BorderRadius.circular(16),
                child: InkWell(
                  onTap: () => onSelect(it.level),
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 14,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected
                            ? Colors.green.shade700
                            : Colors.green.shade200,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(it.icon, color: Colors.green.shade800),
                        const SizedBox(width: 6),
                        Text(
                          it.label,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: isSelected
                                ? FontWeight.w600
                                : FontWeight.w600,
                            color: Colors.green.shade900,
                          ),
                        ),
                        if (isSelected) ...[
                          const SizedBox(width: 4),
                          Icon(
                            Icons.check_circle,
                            size: 16,
                            color: Colors.green.shade800,
                          ),
                        ] else ...[
                          const SizedBox(width: 20),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
