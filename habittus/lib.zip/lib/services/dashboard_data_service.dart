import '../repositories/supabase/supabase_water_repository.dart';
import '../repositories/supabase/supabase_sleep_repository.dart';
import '../repositories/supabase/supabase_mood_repository.dart';
import '../repositories/supabase/supabase_activity_repository.dart';
import '../repositories/supabase/supabase_meal_repository.dart';
import '../repositories/supabase/supabase_habit_repository.dart';

/// Serviço centralizado para obter dados do Dashboard
/// Agrega informações de todos os módulos para exibição no ecrã principal
class DashboardDataService {
  final SupabaseWaterRepository _waterRepo = SupabaseWaterRepository();
  final SupabaseSleepRepository _sleepRepo = SupabaseSleepRepository();
  final SupabaseMoodRepository _moodRepo = SupabaseMoodRepository();
  final SupabaseActivityRepository _activityRepo = SupabaseActivityRepository();
  final SupabaseMealRepository _mealRepo = SupabaseMealRepository();
  final SupabaseHabitRepository _habitRepo = SupabaseHabitRepository();

  /// Obtém todos os dados do dashboard para uma data
  Future<DashboardData> getDashboardData(DateTime date, int visitorId) async {
    final waterSummary = await _waterRepo.getDailySummary(date, visitorId);
    final sleepSession = await _sleepRepo.getByDate(date, visitorId);
    final mood = await _moodRepo.getByDate(date, visitorId);
    final mealSummary = await _mealRepo.getDailySummary(date, visitorId);
    
    // Para atividades, obter do dia
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));
    final activities = await _activityRepo.getByDateRange(
      startOfDay, endOfDay, visitorId.toString()
    );
    
    final totalActivityMinutes = activities.fold<int>(
      0, (sum, a) => sum + a.durationMinutes
    );
    final totalActivityCalories = activities.fold<int>(
      0, (sum, a) => sum + (a.caloriesBurned ?? 0)
    );

    return DashboardData(
      date: date,
      waterMl: waterSummary.totalMl,
      waterGoalMl: 2000,
      sleepMinutes: sleepSession?.durationMinutes ?? 0,
      sleepQuality: sleepSession?.qualityScore ?? 0,
      moodLevel: mood?.moodLevel.value ?? 0,
      caloriesConsumed: mealSummary.totalCalories,
      caloriesGoal: 2000,
      activityMinutes: totalActivityMinutes,
      activityCalories: totalActivityCalories,
      mealsCount: mealSummary.mealCount,
      activitiesCount: activities.length,
    );
  }

  /// Obtém dados semanais para gráficos
  Future<WeeklyChartData> getWeeklyChartData(DateTime startDate, int visitorId) async {
    final waterSummary = await _waterRepo.getWeeklySummary(startDate, visitorId);
    final sleepSummary = await _sleepRepo.getWeeklySummary(startDate, visitorId);
    final moodSummary = await _moodRepo.getWeeklySummary(startDate, visitorId);
    final activitySummary = await _activityRepo.getWeeklySummary(
      startDate, visitorId.toString()
    );
    final mealSummary = await _mealRepo.getWeeklySummary(startDate, visitorId);
    final habitSummary = await _habitRepo.getWeeklySummary(visitorId, startDate);

    // Extrair valores normalizados para gráficos
    final waterValues = waterSummary.map((s) => s.normalizedValue).toList();
    final sleepValues = _sleepRepo.getWeeklyChartValues(sleepSummary);
    final moodValues = _moodRepo.getWeeklyChartValues(moodSummary);
    final activityValues = _activityRepo.getWeeklyChartValues(activitySummary);
    final mealValues = _mealRepo.getWeeklyChartValues(mealSummary);
    final habitValues = _habitRepo.getWeeklyChartValues(habitSummary);

    return WeeklyChartData(
      startDate: startDate,
      waterValues: waterValues,
      sleepValues: sleepValues,
      moodValues: moodValues,
      activityValues: activityValues,
      mealValues: mealValues,
      habitValues: habitValues,
      labels: _getWeekLabels(startDate),
    );
  }

  /// Obtém resumo rápido para widget do dashboard
  Future<QuickSummary> getQuickSummary(int visitorId) async {
    final today = DateTime.now();
    final todayData = await getDashboardData(today, visitorId);
    
    // Calcular início da semana (segunda-feira)
    final weekStart = today.subtract(Duration(days: today.weekday - 1));
    final weeklyData = await getWeeklyChartData(weekStart, visitorId);

    // Médias da semana
    final avgWater = weeklyData.waterValues.isEmpty ? 0.0 
        : weeklyData.waterValues.reduce((a, b) => a + b) / weeklyData.waterValues.length;
    final avgSleep = weeklyData.sleepValues.isEmpty ? 0.0
        : weeklyData.sleepValues.reduce((a, b) => a + b) / weeklyData.sleepValues.length;
    final avgMood = weeklyData.moodValues.isEmpty ? 0.0
        : weeklyData.moodValues.reduce((a, b) => a + b) / weeklyData.moodValues.length;

    return QuickSummary(
      todayData: todayData,
      weeklyWaterAvg: avgWater,
      weeklySleepAvg: avgSleep,
      weeklyMoodAvg: avgMood,
    );
  }

  List<String> _getWeekLabels(DateTime startDate) {
    const dayNames = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
    final labels = <String>[];
    
    for (int i = 0; i < 7; i++) {
      final date = startDate.add(Duration(days: i));
      labels.add(dayNames[date.weekday - 1]);
    }
    
    return labels;
  }
}

/// Dados do dashboard para um dia
class DashboardData {
  final DateTime date;
  final int waterMl;
  final int waterGoalMl;
  final int sleepMinutes;
  final int sleepQuality;
  final int moodLevel;
  final int caloriesConsumed;
  final int caloriesGoal;
  final int activityMinutes;
  final int activityCalories;
  final int mealsCount;
  final int activitiesCount;

  DashboardData({
    required this.date,
    required this.waterMl,
    required this.waterGoalMl,
    required this.sleepMinutes,
    required this.sleepQuality,
    required this.moodLevel,
    required this.caloriesConsumed,
    required this.caloriesGoal,
    required this.activityMinutes,
    required this.activityCalories,
    required this.mealsCount,
    required this.activitiesCount,
  });

  // Getters úteis
  double get waterProgress => waterMl / waterGoalMl;
  double get caloriesProgress => caloriesConsumed / caloriesGoal;
  
  String get sleepFormatted {
    final hours = sleepMinutes ~/ 60;
    final mins = sleepMinutes % 60;
    return '${hours}h${mins.toString().padLeft(2, '0')}';
  }

  String get waterFormatted => '${(waterMl / 1000).toStringAsFixed(1)}L';
  
  String get activityFormatted {
    if (activityMinutes < 60) return '${activityMinutes}min';
    final hours = activityMinutes ~/ 60;
    final mins = activityMinutes % 60;
    return '${hours}h${mins > 0 ? '${mins}min' : ''}';
  }
}

/// Dados semanais para gráficos
class WeeklyChartData {
  final DateTime startDate;
  final List<double> waterValues;
  final List<double> sleepValues;
  final List<double> moodValues;
  final List<double> activityValues;
  final List<double> mealValues;
  final List<double> habitValues;
  final List<String> labels;

  WeeklyChartData({
    required this.startDate,
    required this.waterValues,
    required this.sleepValues,
    required this.moodValues,
    required this.activityValues,
    required this.mealValues,
    required this.habitValues,
    required this.labels,
  });
}

/// Resumo rápido para dashboard
class QuickSummary {
  final DashboardData todayData;
  final double weeklyWaterAvg;
  final double weeklySleepAvg;
  final double weeklyMoodAvg;

  QuickSummary({
    required this.todayData,
    required this.weeklyWaterAvg,
    required this.weeklySleepAvg,
    required this.weeklyMoodAvg,
  });

  // Comparação com média semanal
  String get waterTrend {
    final todayNorm = todayData.waterProgress;
    if (todayNorm > weeklyWaterAvg + 0.1) return 'acima';
    if (todayNorm < weeklyWaterAvg - 0.1) return 'abaixo';
    return 'na média';
  }
}
