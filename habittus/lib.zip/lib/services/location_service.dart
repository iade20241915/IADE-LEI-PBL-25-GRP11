import 'package:geolocator/geolocator.dart';

/// Modelo para coordenadas GPS
class GpsCoordinate {
  final double latitude;
  final double longitude;
  final double? altitude;
  final DateTime timestamp;

  GpsCoordinate({
    required this.latitude,
    required this.longitude,
    this.altitude,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'lat': latitude,
      'lng': longitude,
      'altitude_m': altitude,
      'recorded_at': timestamp.toIso8601String(),
    };
  }

  @override
  String toString() => 'GpsCoordinate(lat: $latitude, lng: $longitude, alt: $altitude)';
}

/// Serviço para obter localização GPS
/// Usado para tracking de atividades físicas (Corrida, Caminhada, Ciclismo)
class LocationService {
  static final LocationService _instance = LocationService._();
  static LocationService get instance => _instance;

  LocationService._();

  /// Verifica se o serviço de localização está ativo
  Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// Verifica e solicita permissões de localização
  Future<LocationPermission> checkAndRequestPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    return permission;
  }

  /// Verifica se tem permissão para usar localização
  Future<bool> hasPermission() async {
    final permission = await Geolocator.checkPermission();
    return permission == LocationPermission.always ||
        permission == LocationPermission.whileInUse;
  }

  /// Obtém a localização atual
  Future<GpsCoordinate?> getCurrentLocation() async {
    try {
      // Verificar se serviço está ativo
      final serviceEnabled = await isLocationServiceEnabled();
      if (!serviceEnabled) {
        return null;
      }

      // Verificar permissões
      final permission = await checkAndRequestPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return null;
      }

      // Obter posição
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10),
      );

      return GpsCoordinate(
        latitude: position.latitude,
        longitude: position.longitude,
        altitude: position.altitude,
        timestamp: position.timestamp,
      );
    } catch (e) {
      print('Erro ao obter localização: $e');
      return null;
    }
  }

  /// Obtém a última localização conhecida (mais rápido)
  Future<GpsCoordinate?> getLastKnownLocation() async {
    try {
      final position = await Geolocator.getLastKnownPosition();
      if (position == null) return null;

      return GpsCoordinate(
        latitude: position.latitude,
        longitude: position.longitude,
        altitude: position.altitude,
        timestamp: position.timestamp,
      );
    } catch (e) {
      print('Erro ao obter última localização: $e');
      return null;
    }
  }

  /// Calcula distância entre dois pontos em metros
  double calculateDistance(GpsCoordinate start, GpsCoordinate end) {
    return Geolocator.distanceBetween(
      start.latitude,
      start.longitude,
      end.latitude,
      end.longitude,
    );
  }

  /// Calcula distância em quilómetros
  double calculateDistanceKm(GpsCoordinate start, GpsCoordinate end) {
    return calculateDistance(start, end) / 1000;
  }
}

/// Tipos de atividade que requerem tracking GPS
class GpsActivityTypes {
  static const List<String> trackableActivities = [
    'running',
    'walking',
    'cycling',
    'hiking',
  ];

  /// Verifica se o tipo de atividade requer GPS
  static bool requiresGps(String activityType) {
    return trackableActivities.contains(activityType.toLowerCase());
  }
}
