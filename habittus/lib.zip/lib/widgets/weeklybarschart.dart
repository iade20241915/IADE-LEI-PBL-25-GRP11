import 'package:flutter/material.dart';

/// Gráfico de barras para sono
class WeeklyBarsChart extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final List<String>? hoursLabels;

  const WeeklyBarsChart({
    super.key,
    this.values = const [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    this.labels = const ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'],
    this.hoursLabels,
  });

  @override
  Widget build(BuildContext context) {
    final displayValues = values.length >= 7 
        ? values 
        : List.filled(7, 0.0);
    final displayLabels = labels.length >= 7 
        ? labels 
        : const ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'];

    return SizedBox(
      height: 160,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(7, (i) {
          final value = displayValues[i].clamp(0.0, 1.2);
          final hasData = value > 0;
          
          return Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Label de horas (se houver)
                if (hoursLabels != null && hoursLabels!.length > i && hasData)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(
                      hoursLabels![i],
                      style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                
                // Barra
                Expanded(
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: 10,
                      height: hasData ? 100 * value : 4,
                      decoration: BoxDecoration(
                        color: hasData 
                            ? const Color(0xFF2F5B2F) 
                            : const Color(0xFFDDECCF),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                
                // Label do dia
                _DayBubble(
                  text: displayLabels[i],
                  isActive: hasData,
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _DayBubble extends StatelessWidget {
  final String text;
  final bool isActive;

  const _DayBubble({required this.text, this.isActive = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 26,
      height: 26,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFF2F5B2F) : const Color(0xFFDDECCF),
        borderRadius: BorderRadius.circular(13),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: isActive ? Colors.white : Colors.black87,
        ),
      ),
    );
  }
}
